# Kişisel Portfolyo Sayfası Oluşturma - Yapılacaklar Listesi

## GitHub Kurulumu
- [x] GitHub hesabı oluşturma
- [x] GitHub'da "portfolio" adında repository oluşturma (Node.js .gitignore ile)
- [x] Repository'yi yerel ortama klonlama

## React Projesi Oluşturma
- [x] Repository içinde temel React projesi oluşturma
- [x] Gerekli paketlerin kurulumu

## Portfolyo Sayfası Geliştirme
- [x] Ana sayfa tasarımı
- [x] "Ben kimim?" sayfası/bölümü
- [x] "Neler yapabilirim?" sayfası/bölümü
- [x] Portfolyo sayfası/bölümü
- [x] İletişim sayfası/bölümü ve form oluşturma

## Sosyal Medya Bağlantıları
- [x] X hesabı bağlantısı
- [x] GitHub hesabı bağlantısı (Zorunlu)
- [x] Facebook hesabı bağlantısı

## Tasarım ve Duyarlılık
- [x] Görsel açıdan güzel bir tasarım oluşturma
- [x] Responsive (mobil uyumlu) tasarım sağlama
- [x] Örnek site ile benzer kalitede tasarım

## Test ve Yayınlama
- [x] Web sitesinin sorunsuz çalıştığını test etme
- [x] Vercel'de yayınlama
- [x] GitHub repository'sini public yapma
- [x] Final kontrolleri yapma
